export class GLOBALS{
baseUrl: string;
user:any = {};

constructor(){
	this.baseUrl ='http://iitoverflow.herokuapp.com';


}
   
} 